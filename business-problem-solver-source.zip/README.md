# Business Problem Solver

Railway-ready initial web application.

Run with `npm start`.
