const http=require("http"),fs=require("fs"),path=require("path");
const port=process.env.PORT||3000, root=path.join(__dirname,"public");
http.createServer((req,res)=>{
 if(req.url==="/health"||req.url==="/api/health"){res.writeHead(200,{"Content-Type":"application/json"});return res.end(JSON.stringify({status:"ok",service:"business-problem-solver"}))}
 let p=req.url.split("?")[0]; if(p==="/")p="/index.html";
 const f=path.join(root,p); if(!f.startsWith(root)){res.writeHead(403);return res.end("Forbidden")}
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end("Not found")}
 const t={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8"}[path.extname(f)]||"application/octet-stream";
 res.writeHead(200,{"Content-Type":t});res.end(d)})}).listen(port,"0.0.0.0",()=>console.log("Business Problem Solver listening on "+port));
